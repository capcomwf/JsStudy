function help() {
	window.open("../html/help.html","Help", "status = 1, height = 500, width = 500, resizable = 0" )
}