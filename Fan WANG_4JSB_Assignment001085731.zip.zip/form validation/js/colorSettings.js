function changeBgd (textField) {
	textField.style.background = "#FFFFCC";
}
 
function resetBgd (textField) {
	textField.style.background = "white";
}